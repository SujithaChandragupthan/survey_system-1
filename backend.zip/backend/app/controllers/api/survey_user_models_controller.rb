class Api::SurveyUserModelsController < ApplicationController
  before_action :set_survey_user_model, only: %i[ show update destroy ]

  # GET /survey_user_models
  def index
    @survey_user_models = SurveyUserModel.all

    render json: @survey_user_models
  end

  # GET /survey_user_models/1
  def show
    render json: @survey_user_model
  end
 # POST /api/survey_user_models/login
 def login
  user = SurveyUserModel.find_by(username: params[:username])

  if user
    render json: { id: user.id, username: user.username, password: user.password, roles: user.roles }
  else
    render json: { error: 'Invalid username or password' }, status: :unauthorized
  end
end


#http://localhost:3000/api/survey_users/role
def showByRole
  @survey_user_model = SurveyUserModel.where(roles: params[:role])

  if @survey_user_model.any?
    render json: @survey_user_model
  else
    render json: { error: 'Invalid role' }, status: :unauthorized
  end
end
  # POST /survey_user_models
  def create
    @survey_user_model = SurveyUserModel.new(survey_user_model_params)

    if @survey_user_model.save
      render json: @survey_user_model, status: :created
    else
      render json: @survey_user_model.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /survey_user_models/1
  def update
    if @survey_user_model.update(survey_user_model_params)
      render json: @survey_user_model
    else
      render json: @survey_user_model.errors, status: :unprocessable_entity
    end
  end

  # DELETE /survey_user_models/1
  def destroy
    @survey_user_model.destroy!
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_survey_user_model
      @survey_user_model = SurveyUserModel.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def survey_user_model_params
      params.expect(survey_user_model: [ :username, :password, :roles ])
    end
end
