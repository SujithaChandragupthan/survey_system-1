class Api::SurveyModelsController < ApplicationController
  before_action :set_survey_model, only: %i[ show update destroy ]
  # GET /survey_models
  def index
    @survey_models = SurveyModel.all

    render json: @survey_models
  end

   # GET /survey_models/1
   def show
    render json: @survey_models
  end

  def showByRole
    username = params[:username]
    @user = SurveyUserModel.find_by(username: username)
  
    if @user.nil? || @user.roles.blank?
      return render json: { error: 'Invalid username or roles' }, status: :unauthorized
    end
  
    if @user.roles.include?("admin") || @user.roles.include?("manager")
      @survey_models = SurveyModel.all
      render json: @survey_models
    else
      # For regular users, fetch their assigned survey questions
      questions = SurveyQuestion.where(survey_user_model_id: @user.id)
  
      # Extract unique survey_model_ids from these questions
      survey_model_ids = questions.pluck(:survey_model_id).uniq
  
      # Fetch the corresponding surveys
      surveys = SurveyModel.where(id: survey_model_ids)
      render json: surveys
    end
  end
  


  # POST /survey_models
  def create
    @survey_model = SurveyModel.new(survey_model_params)

    if @survey_model.save
      render status: :created
    else
      render json: @survey_model.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /survey_models/1
  def update
    if @survey_model.update(survey_model_params)
      render json: @survey_model
    else
      render json: @survey_model.errors, status: :unprocessable_entity
    end
  end

  # DELETE /survey_models/1
  def destroy
    @survey_model.destroy!
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_survey_model
      @survey_model = SurveyModel.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def survey_model_params
      params.expect(survey_model: [ :name, :description, :creator ])
    end
end
