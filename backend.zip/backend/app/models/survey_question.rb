class SurveyQuestion < ApplicationRecord
  belongs_to :survey_model
  belongs_to :survey_user_model

  validates :name, presence: true
end
