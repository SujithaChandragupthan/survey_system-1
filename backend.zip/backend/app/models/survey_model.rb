class SurveyModel < ApplicationRecord
    has_many :survey_questions, dependent: :destroy
  
    validates :name, presence: true
    validates :creator, presence: true
  end
  