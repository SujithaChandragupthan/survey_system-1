class SurveyUserModel < ApplicationRecord
    has_many :survey_questions, dependent: :destroy
    validates :username, presence: true
    validates :roles, presence: true
end
