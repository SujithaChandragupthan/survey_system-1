require 'rails_helper'

RSpec.describe SurveyUserModel, type: :model do
  it 'is valid with valid attributes' do
    user = SurveyUserModel.new(username: 'user1', password: 'password', roles: 'user')
    expect(user).to be_valid
  end

  it 'is invalid without a username' do
    user = SurveyUserModel.new(id: 1, password: 'password', roles: 'admin')
    expect(user).not_to be_valid
  end

  it 'is invalid without a role' do
    user = SurveyUserModel.new(id: 1, username: 'admin', password: 'secret')
    expect(user).not_to be_valid
  end
end
