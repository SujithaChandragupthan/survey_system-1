require 'rails_helper'

RSpec.describe SurveyModel, type: :model do
  it 'is valid with valid attributes' do
    survey = SurveyModel.new(name: 'Survey 1', description: 'A test survey', creator: 'admin')
    expect(survey).to be_valid
  end

  it 'is invalid without a name' do
    survey = SurveyModel.new(id: 1, description: 'Missing name', creator: 'admin')
    expect(survey).not_to be_valid
  end

  it 'is invalid without a creator' do
    survey = SurveyModel.new(id:2 ,name: 'Survey 2', description: 'Missing creator')
    expect(survey).not_to be_valid
  end
end
