require 'rails_helper'

RSpec.describe SurveyQuestion, type: :model do
  let(:user) { SurveyUserModel.create(username: 'user1', password: 'pass', roles: 'user') }
  let(:survey) { SurveyModel.create(name: 'Survey 1', description: 'Description', creator: 'admin') }

  it 'is valid with valid attributes' do
    question = SurveyQuestion.new(
      name: 'Q1',
      label: 'What is your name?',
      field_type: 'string',
      response: 'response',
      status: 'new',
      survey_model: survey,
      survey_user_model: user
    )
    expect(question).to be_valid
  end

  it 'is invalid without a name' do
    question = SurveyQuestion.new(id:1, field_type: 'string', survey_model: survey, survey_user_model: user)
    expect(question).not_to be_valid
  end
end
