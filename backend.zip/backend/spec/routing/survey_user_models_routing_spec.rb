require "rails_helper"

RSpec.describe Api::SurveyUserModelsController, type: :routing do
  describe "routing" do
    it "routes to #index" do
      expect(get: "/api/survey_user_models").to route_to("api/survey_user_models#index")
    end

    it "routes to #show" do
      expect(get: "/api/survey_user_models/1").to route_to("api/survey_user_models#show", id: "1")
    end


    it "routes to #create" do
      expect(post: "/api/survey_user_models").to route_to("api/survey_user_models#create")
    end

    it "routes to #update via PUT" do
      expect(put: "/api/survey_user_models/1").to route_to("api/survey_user_models#update", id: "1")
    end

    it "routes to #update via PATCH" do
      expect(patch: "/api/survey_user_models/1").to route_to("api/survey_user_models#update", id: "1")
    end

    it "routes to #destroy" do
      expect(delete: "/api/survey_user_models/1").to route_to("api/survey_user_models#destroy", id: "1")
    end
  end
end
