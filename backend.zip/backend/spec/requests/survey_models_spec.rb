require 'rails_helper'

RSpec.describe Api::SurveyModelsController, type: :controller do
  describe 'GET #index' do
    it 'returns all survey models' do
      SurveyModel.create!(name: 'Survey 1', description: 'Test', creator: 'admin')
      get :index
      expect(response).to have_http_status(:ok)
    end
  end

  describe 'POST #create' do
    it 'creates a new survey model' do
      post :create, params: { survey_model: { name: 'Survey 2', description: 'Test 2', creator: 'admin' } }
      expect(response).to have_http_status(:created)
    end
  end

  describe 'GET #showByRole' do
    it 'returns all surveys for admin' do
      user = SurveyUserModel.create!(username: 'admin', password: 'pass', roles: 'admin')
      SurveyModel.create!(name: 'Survey 3', description: 'A test survey', creator: 'admin')
      get :showByRole, params: { username: user.username }
      expect(response).to have_http_status(:ok)
    end
  end
end
