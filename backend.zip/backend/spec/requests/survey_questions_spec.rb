require 'rails_helper'

RSpec.describe Api::SurveyQuestionsController, type: :controller do
  let(:user) { SurveyUserModel.create!(username: 'user1', password: 'pass', roles: 'user') }
  let(:survey) { SurveyModel.create!(name: 'Survey A', description: 'Details', creator: 'admin') }

  describe 'GET #index' do
    it 'returns all survey questions' do
      SurveyQuestion.create!(
        name: 'Q1',
        label: 'Label 1',
        field_type: 'string',
        status: 'new',
        survey_model: survey,
        survey_user_model: user
      )
      get :index
      expect(response).to have_http_status(:ok)
    end
  end

  describe 'POST #create' do
    it 'creates a survey question' do
      post :create, params: {
        survey_question: {
          name: 'Q2',
          label: 'Label 2',
          field_type: 'string',
          status: 'new',
          survey_model_id: survey.id,
          survey_user_model_id: user.id
        }
      }
      expect(response).to have_http_status(:created)
    end
  end

end
