require 'rails_helper'

RSpec.describe Api::SurveyUserModelsController, type: :controller do
  describe 'GET #index' do
    it 'returns all users' do
      SurveyUserModel.create!(username: 'user1', password: 'test', roles: 'user')
      get :index
      expect(response).to have_http_status(:ok)
    end
  end

  describe 'POST #login' do
    it 'logs in a valid user' do
      SurveyUserModel.create!(username: 'loginuser', password: '123', roles: 'user')
      post :login, params: { username: 'loginuser' }
      expect(response).to have_http_status(:ok)
    end
  end

  describe 'GET #showByRole' do
    it 'returns users by role' do
      SurveyUserModel.create!(username: 'u1', password: '123', roles: 'user')
      get :showByRole, params: { role: 'user' }
      expect(response).to have_http_status(:ok)
    end
  end
end
