class CreateSurveyUserModels < ActiveRecord::Migration[8.0]
  def change
    create_table :survey_user_models do |t|
      t.string :username
      t.string :password
      t.string :roles

      t.timestamps
    end
  end
end
