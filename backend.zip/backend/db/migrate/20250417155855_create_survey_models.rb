class CreateSurveyModels < ActiveRecord::Migration[8.0]
  def change
    create_table :survey_models do |t|
      t.string :name
      t.text :description
      t.string :creator

      t.timestamps
    end
  end
end
