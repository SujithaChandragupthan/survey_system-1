class CreateSurveyQuestions < ActiveRecord::Migration[8.0]
  def change
    create_table :survey_questions do |t|
      t.text :name
      t.text :label
      t.string :field_type
      t.text :response
      t.string :status
      t.references :survey_model, null: false, foreign_key: true
      t.references :survey_user_model, null: false, foreign_key: true

      t.timestamps
    end
  end
end
