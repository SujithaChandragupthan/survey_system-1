SurveyQuestion.destroy_all()
SurveyUser.destroy_all()
SurveyModel.destroy_all()

SurveyUserModel.create!(username: "admin1", password: "paSS#w0rd",  roles: "admin")
SurveyUserModel.create!(username: "manager1", password: "paSS#w0rd",  roles: "manager")
SurveyUserModel.create!(username: "user1", password: "paSS#w0rd",  roles: "user")
SurveyUserModel.create!(username: "user2", password: "paSS#w0rd",  roles: "user")


SurveyModel.create!(name: "Age Survey", description: "survey to find youth", creator: "admin1")
SurveyModel.create!(name: "Identity Survey", description: "Survey to help First Nations", creator: "manager1")
SurveyModel.create!(name: "Income Survey", description: "General survey", creator: "admin1")


SurveyQuestion.create!(name: "What is your age?", label: "Age description", field_type: "string", response: "", status: :"new", survey_model_id: 1, survey_user_model_id:2)
SurveyQuestion.create!(name: "Will you Identity as First Nations?", label: "Identity", field_type: "boolean", response: "" , status: :"assigned", survey_model_id: 2, survey_user_model_id:2)
SurveyQuestion.create!(name: "What is your income", label: "Income", field_type: "integer", response: "100000", status: :"completed", survey_model_id: 3, survey_user_model_id:1)
