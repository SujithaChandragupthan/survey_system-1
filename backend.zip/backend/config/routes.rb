Rails.application.routes.draw do
  devise_for :users, controllers: {
    sessions: 'api/survey_users/sessions'
  }
  namespace :api do
    # Other resource routes
    resources :survey_questions
    resources :survey_models
    resources :survey_user_models
    # Custom route for SurveyUserController's login action
    post 'survey_user_models/login', to: 'survey_user_models#login'
    get 'survey_user_models/showByRole/:role', to: 'survey_user_models#showByRole'
    get 'survey_questions/survey/:id', to: 'survey_questions#survey'
    delete 'survey_questions/removeBySurvey/:survey_id', to: 'survey_questions#removeBySurvey'
    get 'survey_models/showByRole/:username', to: 'survey_models#showByRole'


  end
end
