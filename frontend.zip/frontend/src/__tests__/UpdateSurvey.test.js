import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import UpdateSurvey from '../components/Survey/UpdateSurvey';
import { ChakraProvider } from '@chakra-ui/react';
import axios from 'axios';

// Mock axios
jest.mock('axios');

const mockUser = { roles: 'admin', username: 'adminUser' };
const mockSurvey = { id: 1, name: 'Survey A', description: 'A test survey' };
const mockFetchSurveys = jest.fn();

const renderComponent = () => {
    return render(
        <ChakraProvider>
            <UpdateSurvey user={mockUser} survey={mockSurvey} BASE_URL="http://localhost:3000/api/" fetchSurveys={mockFetchSurveys} />
        </ChakraProvider>
    );
};

describe('UpdateSurvey Component', () => {
    it('renders update button for admin', () => {
        renderComponent();
        expect(screen.getByText(/Update/i)).toBeInTheDocument();
    });

    it('opens modal and updates input values', async () => {
        renderComponent();
        fireEvent.click(screen.getByText(/Update/i));

        const nameInput = screen.getByLabelText(/Survey Name/i);
        const descInput = screen.getByLabelText(/Description/i);

        fireEvent.change(nameInput, { target: { value: 'Updated Survey' } });
        fireEvent.change(descInput, { target: { value: 'Updated Description' } });

        expect(nameInput.value).toBe('Updated Survey');
        expect(descInput.value).toBe('Updated Description');
    });

    it('calls axios.put on submit', async () => {
        axios.put.mockResolvedValueOnce({ status: 200 });
        renderComponent();
        fireEvent.click(screen.getByText(/Update/i));

        fireEvent.change(screen.getByLabelText(/Survey Name/i), { target: { value: 'Updated Survey' } });
        fireEvent.change(screen.getByLabelText(/Description/i), { target: { value: 'Updated Description' } });

        fireEvent.click(screen.getByText(/Submit/i));

        await waitFor(() => {
            expect(axios.put).toHaveBeenCalledWith('http://localhost:3000/api/survey_models/1', {
                name: 'Updated Survey',
                description: 'Updated Description',
                creator: 'adminUser',
            });
        });

        expect(mockFetchSurveys).toHaveBeenCalled();
    });
});
