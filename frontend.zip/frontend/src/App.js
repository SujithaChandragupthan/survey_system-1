import * as React from 'react'

// 1. import `ChakraProvider` component
import { ChakraProvider } from '@chakra-ui/react'
import LoginPage from './components/Pages/LoginPage';
import { Routes, Route } from 'react-router-dom';
import SurveyManagement from './components/Pages/SurveyManagement';
import SurveyQuestionsPage from './components/Pages/SurveyQuestionsPage';

function App() {
  // 2. Wrap ChakraProvider at the root of your app
  return (
    <ChakraProvider>
      <Routes>
        <Route path="/" element={<LoginPage />} ></Route>
        <Route path="survey" element={<SurveyManagement />} ></Route>
        <Route path="/survey/:surveyId/:surveyName/question" element={<SurveyQuestionsPage />} />

      </Routes>
    </ChakraProvider>
  )
}

export default App;

/**
 * create api
 * GET /api/survey_questions/survey/:survey_name

GET /api/survey_users?role=user

DELETE /api/survey_questions/:id
 */