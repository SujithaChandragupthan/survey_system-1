import React, { useState } from 'react';
import {
    Button,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    FormControl,
    FormLabel,
    Input,
    Select,
    useDisclosure,
    useToast
} from '@chakra-ui/react';
import axios from 'axios';

const CreateSurveyQuestion = ({ user, BASE_URL, survey }) => {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const toast = useToast();

    const [name, setName] = useState('');
    const [label, setLabel] = useState('');
    const [fieldType, setFieldType] = useState('string');

    const handleCreateSurvey = async () => {
        try {
            const payload = {
                name: name,
                label: label,
                field_type: fieldType,
                status: 'new',
                survey_model_id: survey.id
            };

            const response = await axios.post(`${BASE_URL}survey_questions`, payload);
            console.log(response.data);

            toast({
                title: 'Survey Question Created',
                status: 'success',
                duration: 3000,
                isClosable: true,
            });
            onClose();
        } catch (error) {
            toast({
                title: 'Error creating survey question',
                description: error.message,
                status: 'error',
                duration: 5000,
                isClosable: true,
            });
        }
    };

    return (
        <>
            {(user?.roles === 'admin' || user?.roles === 'manager') && (
                <>
                    <Button colorScheme="teal" onClick={onOpen}>
                        Create Question
                    </Button>

                    <Modal isOpen={isOpen} onClose={onClose}>
                        <ModalOverlay />
                        <ModalContent>
                            <ModalHeader>Create New Survey Question</ModalHeader>
                            <ModalCloseButton />
                            <ModalBody>
                                <FormControl id="name" isRequired>
                                    <FormLabel>Question Name</FormLabel>
                                    <Input value={name} onChange={(e) => setName(e.target.value)} />
                                </FormControl>

                                <FormControl id="label" mt={4} isRequired>
                                    <FormLabel>Question Label</FormLabel>
                                    <Input value={label} onChange={(e) => setLabel(e.target.value)} />
                                </FormControl>

                                <FormControl id="field_type" mt={4} isRequired>
                                    <FormLabel>Field Type</FormLabel>
                                    <Select value={fieldType} onChange={(e) => setFieldType(e.target.value)}>
                                        <option value="string">String</option>
                                        <option value="integer">Integer</option>
                                        <option value="boolean">Boolean</option>
                                    </Select>
                                </FormControl>
                            </ModalBody>

                            <ModalFooter>
                                <Button colorScheme="blue" mr={3} onClick={handleCreateSurvey}>
                                    Submit
                                </Button>
                                <Button variant="ghost" onClick={onClose}>
                                    Cancel
                                </Button>
                            </ModalFooter>
                        </ModalContent>
                    </Modal>
                </>
            )}
        </>
    );
};

export default CreateSurveyQuestion;
