'use client';
import React, { useState } from 'react';
import {
    Flex, Box, FormControl, FormLabel, Input, Stack, Button, Heading, useColorModeValue
} from '@chakra-ui/react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';// adjust path as needed

export default function LoginPage() {
    const { login } = useAuth();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async () => {
        setError('');
        try {
            const res = await fetch('http://localhost:3000/api/survey_user_models/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username }),
            });

            if (res.ok) {
                const data = await res.json();
                if (data.roles && data.password === password) {
                    console.log("logged in");
                    login(data);
                    navigate('/survey');
                } else {
                    setError('Invalid response from server.');
                }
            } else {
                const errorData = await res.json();
                setError(errorData.error || 'Login failed.');
            }
        } catch (err) {
            setError('An error occurred during login.');
        }
    };


    return (
        <Flex minH={'100vh'} align={'center'} justify={'center'} bg={useColorModeValue('gray.50', 'gray.800')}>
            <Stack spacing={8} mx={'auto'} maxW={'lg'} py={12} px={6}>
                <Stack align={'center'}>
                    <Heading fontSize={'4xl'}>Survey Submission System</Heading>
                </Stack>
                <Box rounded={'lg'} bg={useColorModeValue('white', 'gray.700')} boxShadow={'lg'} p={8}>
                    <Stack spacing={4}>
                        <FormControl id="username">
                            <FormLabel>Username</FormLabel>
                            <Input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
                        </FormControl>
                        <FormControl id="password">
                            <FormLabel>Password</FormLabel>
                            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                        </FormControl>
                        <Stack spacing={10}>
                            <Button onClick={handleLogin} bg={'blue.400'} color={'white'} _hover={{ bg: 'blue.500' }}>
                                Sign in
                            </Button>
                        </Stack>
                    </Stack>
                </Box>
            </Stack>
        </Flex>
    );
}
