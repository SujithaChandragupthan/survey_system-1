import React, { useState, useEffect } from 'react';
import {
    Box,
    Button,
    Input,
    Stack,
    Text,
    Heading,
    Flex,
    useToast,
    Divider
} from '@chakra-ui/react';
import { useAuth } from '../context/AuthContext';
import CreateSurveyQuestion from '../Question/CreateQuestion';
import CreateSurvey from '../Survey/CreateSurvey';
import DeleteSurvey from '../Survey/DeleteSurvey';
import UpdateSurvey from '../Survey/UpdateSurvey';
import { useNavigate } from 'react-router-dom';

const SurveyManagement = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [surveys, setSurveys] = useState([]);
    const [filteredSurveys, setFilteredSurveys] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const toast = useToast();
    const BASE_URL = 'http://localhost:3000/api/';


    useEffect(() => {
        fetchSurveys();
    }, []);

    const fetchSurveys = async () => {
        try {
            const response = await fetch(`${BASE_URL}survey_models/showByRole/${user.username}`, {
                method: 'GET',
            });

            if (!response.ok) {
                throw new Error('Failed to fetch surveys');
            }

            const data = await response.json();
            console.log(data);
            setSurveys(data);
            setFilteredSurveys(data);
        } catch (error) {
            toast({
                title: 'Error fetching surveys',
                description: error.message,
                status: 'error',
                duration: 5000,
                isClosable: true,
            });
        }
    };

    const handleSearch = (e) => {
        const term = e.target.value;
        setSearchTerm(term);
        const filtered = surveys.filter((survey) =>
            survey.name.toLowerCase().includes(term.toLowerCase()) || survey.creator.toLowerCase().includes(term.toLowerCase())
        );
        setFilteredSurveys(filtered);
    };


    return (

        //if the user has "user" role, select surveyquestions from surevey_user_assignments and store it
        //select survey_model from survey_question in survey_user_assignemnts record
        //list the respective survey
        <Box p={6}>
            <Flex justify="space-between" align="center" mb={4}>
                <Heading size="lg">Survey Management</Heading>
                <CreateSurvey user={user} BASE_URL={BASE_URL} fetchSurveys={fetchSurveys} />
            </Flex>
            <Input
                placeholder="Search surveys..."
                value={searchTerm}
                onChange={handleSearch}
                mb={4}
            />
            <Stack spacing={2}>
                {filteredSurveys.map((survey) => (
                    <Box key={survey.id} p={1} borderWidth="1px" borderRadius="md">
                        <Flex justify="space-between" align="center">
                            <Text fontSize="md" fontWeight="bold">
                                {survey.name}
                            </Text>
                            <Text fontSize="md" fontWeight="bold">
                                {survey.description}
                            </Text>
                            <Text fontSize="md" fontWeight="bold">
                                {survey.creator}
                            </Text>

                        </Flex>


                        <Flex mt={2} gap={2}>
                            <Button
                                size="sm"
                                onClick={() => navigate(`/survey/${survey.id}/${survey.name}/question`)}
                            >
                                View Questions
                            </Button>
                            <UpdateSurvey user={user} survey={survey} BASE_URL={BASE_URL} fetchSurveys={fetchSurveys} />
                            <DeleteSurvey user={user} survey={survey} BASE_URL={BASE_URL} fetchSurveys={fetchSurveys} />

                            <CreateSurveyQuestion user={user} BASE_URL={BASE_URL} survey={survey} />
                        </Flex>
                    </Box>
                ))}
            </Stack>

        </Box>
    );
};

export default SurveyManagement;
