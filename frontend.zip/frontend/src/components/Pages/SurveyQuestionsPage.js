import React, { useEffect, useState } from 'react';
import {
    Box,
    Divider,
    Stack,
    Text,
    Button,
    useToast,
    Select,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalCloseButton,
    ModalBody,
    ModalFooter,
    Input,
    useDisclosure,
    FormControl,
    FormLabel,
} from '@chakra-ui/react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const SurveyQuestionsPage = () => {
    const { surveyName, surveyId } = useParams();
    const [questions, setQuestions] = useState([]);
    const [users, setUsers] = useState([]);
    const [selectedQuestion, setSelectedQuestion] = useState(null);
    const [editLabel, setEditLabel] = useState('');
    const [editResponse, setEditResponse] = useState('');
    const [editStatus, setEditStatus] = useState('');
    const [assignUser, setAssignUser] = useState('');

    const toast = useToast();
    const { user } = useAuth();

    const {
        isOpen: isUpdateOpen,
        onOpen: onUpdateOpen,
        onClose: onUpdateClose,
    } = useDisclosure();

    const {
        isOpen: isAssignOpen,
        onOpen: onAssignOpen,
        onClose: onAssignClose,
    } = useDisclosure();

    useEffect(() => {
        fetchSurveyQuestions();
        fetchUsersWithUserRole();
    }, []);

    const fetchSurveyQuestions = async () => {
        try {
            const res = await axios.get(`http://localhost:3000/api/survey_questions/survey/${surveyId}`);

            if (!res.data || res.data.length === 0) {
                toast({
                    title: 'No Survey Questions',
                    description: 'No questions found for this survey.',
                    status: 'info',
                    duration: 4000,
                    isClosable: true,
                });
                setQuestions([]);
                return;
            }

            const enrichedQuestions = await Promise.all(
                res.data.map(async (question) => {
                    let assignedUser = null;

                    if (question.survey_user_model_id != null) {
                        try {
                            const userRes = await axios.get(`http://localhost:3000/api/survey_user_models/${question.survey_user_model_id}`);
                            assignedUser = userRes.data;
                        } catch (userErr) {
                            console.error(`Error fetching user ${question.survey_user_model_id}`, userErr);
                        }
                    }

                    return { ...question, assigned_users: assignedUser ? [assignedUser] : [] };
                })
            );

            setQuestions(enrichedQuestions);
            console.log("Enriched Questions:", enrichedQuestions);
        } catch (error) {
            toast({ title: 'Error fetching questions', description: error.message, status: 'error' });
        }
    };



    const fetchUsersWithUserRole = async () => {
        try {
            const res = await axios.get('http://localhost:3000/api/survey_user_models/showByRole/user');
            setUsers(res.data);
        } catch (error) {
            toast({ title: 'Error fetching users', status: 'error' });
        }
    };

    const handleDelete = async (questionId) => {
        try {
            await axios.delete(`http://localhost:3000/api/survey_questions/${questionId}`);
            toast({ title: 'Question deleted', status: 'success' });
            fetchSurveyQuestions();
        } catch (error) {
            toast({ title: 'Delete failed', status: 'error' });
        }
    };

    const handleUpdate = (question) => {
        setSelectedQuestion(question);
        setEditLabel(question.label);
        setEditResponse(question.response);
        onUpdateOpen();
    };

    const handleUpdateSubmit = async () => {
        try {
            await axios.put(`http://localhost:3000/api/survey_questions/${selectedQuestion.id}`, {
                label: editLabel,
                response: editResponse
            });
            toast({ title: 'Question updated', status: 'success' });
            fetchSurveyQuestions();
            onUpdateClose();
        } catch (error) {
            toast({ title: 'Update failed', status: 'error' });
        }
    };

    const handleAssign = (question) => {
        setSelectedQuestion(question);
        onAssignOpen();
    };

    const handleAssignSubmit = async () => {
        try {
            await axios.put(`http://localhost:3000/api/survey_questions/${selectedQuestion.id}`, {
                survey_user_model_id: assignUser,
            });
            toast({ title: 'User assigned', status: 'success' });
            fetchSurveyQuestions();
            onAssignClose();
        } catch (error) {
            toast({ title: 'Assignment failed', status: 'error' });
        }
    };

    return (
        <Box p={6}>
            <Text fontSize="2xl" mb={4}>Survey: {surveyName}</Text>
            {questions.map((question) => (
                <Box key={question.id} mt={6} p={4} borderWidth="1px" borderRadius="md">
                    <Divider mb={2} />
                    <Text fontWeight="bold">Question: {question.name}</Text>
                    <Text>Label: {question.label}</Text>
                    <Text>Status: {question.status}</Text>
                    <Text>Response: {question.response}</Text>

                    <Text mt={2} fontWeight="bold">Assigned Users:</Text>
                    <Stack pl={4}>
                        {(question.assigned_users || []).map((u) => (
                            <Text key={u.id}>{u.username}</Text>
                        ))}
                    </Stack>

                    {/* Editable Response Input for User */}
                    {user.roles === 'user' && (
                        <Box mt={4}>
                            <FormControl>
                                <FormLabel>Response</FormLabel>
                                <Input
                                    placeholder="Enter your response"
                                    value={question.response || ''}
                                    onChange={(e) => {
                                        const updatedQuestions = questions.map((q) =>
                                            q.id === question.id ? { ...q, response: e.target.value } : q
                                        );
                                        setQuestions(updatedQuestions);
                                    }}
                                />
                            </FormControl>

                            <Button
                                size="sm"
                                colorScheme="teal"
                                mt={2}
                                onClick={async () => {
                                    try {
                                        const res = await axios.put(`http://localhost:3000/api/survey_questions/${question.id}`, {
                                            response: question.response,
                                            status: 'completed'
                                        });
                                        setEditStatus('completed');
                                        toast({
                                            title: 'Response submitted',
                                            status: 'success',
                                            duration: 3000,
                                            isClosable: true,
                                        });
                                    } catch (error) {
                                        toast({
                                            title: 'Error submitting response',
                                            status: 'error',
                                            duration: 3000,
                                            isClosable: true,
                                        });
                                    }
                                }}
                            >
                                Submit Response
                            </Button>
                        </Box>
                    )}

                    {/* Admin / Manager Controls */}
                    <Stack direction="row" mt={4}>
                        {(user.roles === 'admin' || user.roles === 'manager') && (
                            <Button size="sm" colorScheme="blue" onClick={() => handleUpdate(question)}>Update</Button>
                        )}
                        {(user.roles === 'admin' || user.roles === 'manager') && (
                            <Button size="sm" colorScheme="green" onClick={() => handleAssign(question)}>Assign</Button>
                        )}
                        {user.roles === 'admin' && (
                            <Button size="sm" colorScheme="red" onClick={() => handleDelete(question.id)}>Delete</Button>
                        )}
                    </Stack>
                </Box>
            ))}


            <Modal isOpen={isUpdateOpen} onClose={onUpdateClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Update Question</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <FormControl>
                            <FormLabel>Label</FormLabel>
                            <Input value={editLabel} onChange={(e) => setEditLabel(e.target.value)} />
                            <FormLabel>Response</FormLabel>
                            <Input value={editResponse} onChange={(e) => setEditResponse(e.target.value)} />
                        </FormControl>
                    </ModalBody>
                    <ModalFooter>
                        <Button colorScheme="blue" onClick={handleUpdateSubmit}>Submit</Button>
                        <Button ml={3} onClick={onUpdateClose}>Cancel</Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>

            <Modal isOpen={isAssignOpen} onClose={onAssignClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Assign User</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <FormControl>
                            <FormLabel>User</FormLabel>
                            <Select placeholder="Select user" onChange={(e) => setAssignUser(e.target.value)}>
                                {users.map((u) => (
                                    <option key={u.id} value={u.id}>{u.username}</option>
                                ))}
                            </Select>
                        </FormControl>
                    </ModalBody>
                    <ModalFooter>
                        <Button colorScheme="green" onClick={handleAssignSubmit}>Assign</Button>
                        <Button ml={3} onClick={onAssignClose}>Cancel</Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </Box>
    );
};

export default SurveyQuestionsPage;
