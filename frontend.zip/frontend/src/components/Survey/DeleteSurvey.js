import {
    Button,
    useDisclosure,
    useToast,
    AlertDialog,
    AlertDialogOverlay,
    AlertDialogContent,
    AlertDialogHeader,
    AlertDialogBody,
    AlertDialogFooter
} from '@chakra-ui/react';
import React, { useRef } from 'react';

const DeleteSurvey = ({ user, survey, BASE_URL, fetchSurveys }) => {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const cancelRef = useRef();
    const toast = useToast();

    const handleDeleteSurvey = async () => {
        try {
            // delete related survey questions
            await fetch(`${BASE_URL}survey_questions/removeBySurvey/${survey.id}`, {
                method: 'DELETE',
            });

            // Delete survey model
            const res = await fetch(`${BASE_URL}survey_models/${survey.id}`, {
                method: 'DELETE',
            });

            if (!res.ok) throw new Error('Failed to delete survey model');

            toast({
                title: 'Survey Deleted',
                description: `Survey "${survey.name}" has been successfully deleted.`,
                status: 'success',
                duration: 3000,
                isClosable: true,
            });

            fetchSurveys();
            onClose();
        } catch (err) {
            toast({
                title: 'Error deleting survey',
                description: err.message,
                status: 'error',
                duration: 5000,
                isClosable: true,
            });
        }
    };

    return (
        <>
            {user?.roles === 'admin' && (
                <>
                    <Button size="sm" colorScheme="red" onClick={onOpen}>
                        Delete
                    </Button>

                    <AlertDialog
                        isOpen={isOpen}
                        leastDestructiveRef={cancelRef}
                        onClose={onClose}
                    >
                        <AlertDialogOverlay>
                            <AlertDialogContent>
                                <AlertDialogHeader fontSize="lg" fontWeight="bold">
                                    Delete Survey
                                </AlertDialogHeader>

                                <AlertDialogBody>
                                    Are you sure you want to delete the survey "{survey.name}"?
                                    This action cannot be undone.
                                </AlertDialogBody>

                                <AlertDialogFooter>
                                    <Button ref={cancelRef} onClick={onClose}>
                                        Cancel
                                    </Button>
                                    <Button colorScheme="red" onClick={handleDeleteSurvey} ml={3}>
                                        Delete
                                    </Button>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialogOverlay>
                    </AlertDialog>
                </>
            )}
        </>
    );
};

export default DeleteSurvey;
