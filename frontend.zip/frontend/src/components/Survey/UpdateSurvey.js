import React, { useState } from 'react';
import {
    Button,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    FormControl,
    FormLabel,
    Input,
    useDisclosure,
    useToast
} from '@chakra-ui/react';
import axios from 'axios';

const UpdateSurvey = ({ user, survey, BASE_URL, fetchSurveys }) => {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const toast = useToast();
    const [surveyName, setSurveyName] = useState(survey.name || '');
    const [surveyDescription, setSurveyDescription] = useState(survey.description || '');

    const handleUpdateSurvey = async () => {
        try {
            const response = await axios.put(`${BASE_URL}survey_models/${survey.id}`, {
                name: surveyName,
                description: surveyDescription,
                creator: user.username
            });

            if (response.status === 200) {
                toast({
                    title: 'Survey Updated',
                    status: 'success',
                    duration: 3000,
                    isClosable: true,
                });
                onClose();
                fetchSurveys();
            } else {
                throw new Error('Failed to update survey');
            }
        } catch (error) {
            toast({
                title: 'Error',
                description: error.message,
                status: 'error',
                duration: 5000,
                isClosable: true,
            });
        }
    };

    return (
        <>
            {user?.roles === 'admin' && (
                <Button size="sm" colorScheme="blue" onClick={onOpen}>
                    Update
                </Button>
            )}

            <Modal isOpen={isOpen} onClose={onClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Update Survey</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <FormControl id="survey-name" isRequired>
                            <FormLabel>Survey Name</FormLabel>
                            <Input
                                value={surveyName}
                                onChange={(e) => setSurveyName(e.target.value)}
                            />
                        </FormControl>

                        <FormControl id="survey-description" mt={4}>
                            <FormLabel>Description</FormLabel>
                            <Input
                                value={surveyDescription}
                                onChange={(e) => setSurveyDescription(e.target.value)}
                            />
                        </FormControl>
                    </ModalBody>

                    <ModalFooter>
                        <Button colorScheme="blue" mr={3} onClick={handleUpdateSurvey}>
                            Submit
                        </Button>
                        <Button variant="ghost" onClick={onClose}>
                            Cancel
                        </Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </>
    );
};

export default UpdateSurvey;
