import React, { useState } from 'react';
import {
    Button,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    FormControl,
    FormLabel,
    Input,
    useDisclosure,
    useToast
} from '@chakra-ui/react';
import axios from 'axios';



const CreateSurvey = ({ user, BASE_URL, fetchSurveys }) => {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const toast = useToast();
    const [surveyName, setSurveyName] = useState('');
    const [surveyDescription, setSurveyDescription] = useState('');

    const handleCreateSurvey = async () => {
        try {
            const response = await axios.post(`${BASE_URL}survey_models`, {
                name: surveyName,
                description: surveyDescription,
                creator: user.username
            });
            console.log(response.data);
            if (response.data.status === "created") {
                console.log("created");
                onClose();
                fetchSurveys();
            } else {
                throw new Error('Failed to create survey');
            }
        } catch (error) {
            toast({
                title: 'Error',
                description: error.message,
                status: 'error',
                duration: 5000,
                isClosable: true,
            });
        }
    };

    return (
        <>
            {user?.roles === 'admin' && (
                <Button colorScheme="teal" onClick={onOpen}>
                    Create Survey
                </Button>
            )}


            <Modal isOpen={isOpen} onClose={onClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Create New Survey</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <FormControl id="survey-name" isRequired>
                            <FormLabel>Survey Name</FormLabel>
                            <Input
                                value={surveyName}
                                onChange={(e) => setSurveyName(e.target.value)}
                            />
                        </FormControl>

                        <FormControl id="survey-description" mt={4}>
                            <FormLabel>Description</FormLabel>
                            <Input
                                value={surveyDescription}
                                onChange={(e) => setSurveyDescription(e.target.value)}
                            />
                        </FormControl>
                    </ModalBody>

                    <ModalFooter>
                        <Button colorScheme="blue" mr={3} onClick={handleCreateSurvey}>
                            Submit
                        </Button>
                        <Button variant="ghost" onClick={onClose}>
                            Cancel
                        </Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </>
    );
};

export default CreateSurvey;
